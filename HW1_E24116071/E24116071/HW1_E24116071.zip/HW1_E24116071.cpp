// HW1_E24116071
// Text-print program
#include <iostream> // allows program to output data to the screen
using namespace std; // program uses names from the std namespace

int main()
{
	cout << "-------------------------------------------" << endl;
	cout << "| Name: Yu-Tzu, Liu                       |" << endl;
	cout << "| School: National Cheng Kung University  |" << endl;
	cout << "| Department: Electrical Engineering      |" << endl;
	cout << "| Email: E24116071@gs.ncku.edu.tw         |" << endl;
	cout << "-------------------------------------------" << endl;
	//display message

	return 0; // indicate that program ended successfully
} // end function main