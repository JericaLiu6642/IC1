HOW TO PLAY:
1.Decide who goes first and what symbol each player will have (o or x).
2.Players must alternate turns, and only one disc can be dropped in each turn.
3.On your turn, drop one of your discs from the top into any of the seven slots. 
4.The game ends when there is a 4-in-a-row or a stalemate.
---------------------------------------------------------------------------------